package com.thep.controller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity() {

    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val NEON = Color.parseColor("#00FFB2")
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var adapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    @Volatile private var connected = false
    private var deviceName = "-"

    private lateinit var root: FrameLayout
    private lateinit var statusBar: TextView
    private lateinit var listBox: LinearLayout
    private var currentCmd = 'S'
    private val sender = object : Runnable {
        override fun run() {
            if (currentCmd != 'S') { send(currentCmd); ui.postDelayed(this, 100) }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, size: Float = 22f, fill: Int = Color.BLACK, stroke: Int = NEON): Button =
        Button(this).apply {
            this.text = text; textSize = size; setTextColor(if (fill == Color.BLACK) stroke else Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; isAllCaps = false
            background = GradientDrawable().apply {
                setColor(fill); setStroke(dp(3), stroke); cornerRadius = dp(18).toFloat()
            }
        }

    private fun label(text: String, size: Float, color: Int = NEON) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); setPadding(dp(16), dp(8), dp(16), dp(8)) }
        setContentView(root)
        showStart()
    }

    // ---------- หน้าเริ่มต้น ----------
    private fun showStart() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        col.addView(label("THEP 4WD", 48f))
        col.addView(label("Bluetooth RC Car Controller", 16f, Color.LTGRAY))
        val c = btn("Connect Bluetooth", 22f)
        c.setOnClickListener { ensurePermissions { showDevices() } }
        col.addView(c, LinearLayout.LayoutParams(dp(320), dp(70)).apply { topMargin = dp(24) })
        setScreen(col)
    }

    // ---------- หน้าเลือกอุปกรณ์ ----------
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == BluetoothDevice.ACTION_FOUND) {
                val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                if (d != null && !found.containsKey(d.address)) { found[d.address] = d; refreshList() }
            }
        }
    }
    private var receiverOn = false

    private fun showDevices() {
        val a = adapter
        if (a == null) { toast("เครื่องนี้ไม่มี Bluetooth"); return }
        if (!a.isEnabled) { toast("กรุณาเปิด Bluetooth ก่อน"); return }
        found.clear()
        a.bondedDevices.forEach { found[it.address] = it }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("เลือกอุปกรณ์ (เลือก THEP_4WD)", 20f))
        val status = label(if (connected) "Connected" else "Disconnected", 14f, Color.LTGRAY)
        col.addView(status)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this)
        val scan = btn("ค้นหาอุปกรณ์", 16f); val back = btn("กลับ", 16f, stroke = Color.GRAY)
        scan.setOnClickListener { startScan() }
        back.setOnClickListener { stopScan(); showStart() }
        row.addView(scan, LinearLayout.LayoutParams(0, dp(56), 1f).apply { marginEnd = dp(8) })
        row.addView(back, LinearLayout.LayoutParams(0, dp(56), 1f))
        col.addView(row)
        setScreen(col)
        refreshList()
    }

    private fun refreshList() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        // THEP_4WD ขึ้นก่อน
        val sorted = found.values.sortedByDescending { it.name == "THEP_4WD" }
        for (d in sorted) {
            val name = d.name ?: "(ไม่มีชื่อ)"
            val b = btn("$name\n${d.address}", 16f, stroke = if (name == "THEP_4WD") NEON else Color.GRAY)
            b.setOnClickListener { stopScan(); connect(d) }
            listBox.addView(b, LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(6) })
        }
    }

    private fun startScan() {
        if (!receiverOn) { registerReceiver(receiver, IntentFilter(BluetoothDevice.ACTION_FOUND)); receiverOn = true }
        adapter?.cancelDiscovery(); adapter?.startDiscovery(); toast("กำลังค้นหา...")
    }
    private fun stopScan() {
        adapter?.cancelDiscovery()
        if (receiverOn) { try { unregisterReceiver(receiver) } catch (_: Exception) {}; receiverOn = false }
    }

    // ---------- เชื่อมต่อ ----------
    private fun connect(d: BluetoothDevice) {
        toast("กำลังเชื่อมต่อ ${d.name}...")
        io.execute {
            try {
                socket?.close()
                val s = d.createRfcommSocketToServiceRecord(SPP)
                adapter?.cancelDiscovery()
                s.connect()
                socket = s; out = s.outputStream; connected = true; deviceName = d.name ?: d.address
                ui.post { showControl() }
                readLoop(s.inputStream)
            } catch (e: Exception) {
                connected = false
                ui.post { toast("เชื่อมต่อไม่สำเร็จ: ${e.message}") }
            }
        }
    }

    private fun readLoop(input: InputStream) {
        val buf = ByteArray(128)
        try {
            while (true) {
                val n = input.read(buf); if (n < 0) break
                val msg = String(buf, 0, n).trim()
                ui.post { if (::statusBar.isInitialized) statusBar.text = statusText("ESP32: $msg") }
            }
        } catch (_: Exception) {}
        if (connected) { connected = false; ui.post { onLost() } }
    }

    private fun onLost() { toast("Bluetooth หลุด"); closeSocket(); showStart() }

    private fun send(c: Char) {
        io.execute {
            try { out?.write(c.code); out?.flush() }
            catch (e: Exception) { if (connected) { connected = false; ui.post { onLost() } } }
        }
    }

    private fun disconnect() {
        currentCmd = 'S'; send('S')
        io.execute { Thread.sleep(150); closeSocket() }
        connected = false
        showStart()
    }
    private fun closeSocket() { try { socket?.close() } catch (_: Exception) {}; socket = null; out = null; connected = false }

    // ---------- หน้าควบคุมรถ ----------
    private fun statusText(extra: String = "ส่งคำสั่ง: $currentCmd") =
        (if (connected) "● Bluetooth Connected" else "○ Disconnected") + "  |  $deviceName  |  $extra"

    private fun showControl() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        statusBar = label(statusText(), 13f).apply { gravity = Gravity.START }
        top.addView(statusBar, LinearLayout.LayoutParams(0, -2, 1f))
        val dc = btn("Disconnect", 13f, stroke = Color.parseColor("#FF5555"))
        dc.setOnClickListener { disconnect() }
        top.addView(dc, LinearLayout.LayoutParams(dp(130), dp(44)))
        col.addView(top)

        val pad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun row(vararg v: View?) = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            v.forEach { x -> addView(x ?: Space(context), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }) }
        }
        fun hold(text: String, cmd: Char) = btn(text, 20f).also { b ->
            b.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { press(cmd); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { release(); true }
                    else -> false
                }
            }
        }
        val stop = btn("หยุด", 22f, fill = Color.parseColor("#CC0000"), stroke = Color.RED)
        stop.setOnClickListener { release() }
        pad.addView(row(null, hold("เดินหน้า", 'F'), null), LinearLayout.LayoutParams(-1, 0, 1f))
        pad.addView(row(hold("เลี้ยวซ้าย", 'L'), stop, hold("เลี้ยวขวา", 'R')), LinearLayout.LayoutParams(-1, 0, 1f))
        pad.addView(row(null, hold("ถอยหลัง", 'B'), null), LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(pad, LinearLayout.LayoutParams(-1, 0, 1f))
        setScreen(col)
    }

    private fun press(c: Char) {
        currentCmd = c; send(c); ui.removeCallbacks(sender); ui.postDelayed(sender, 100)
        if (::statusBar.isInitialized) statusBar.text = statusText()
    }
    private fun release() {
        currentCmd = 'S'; ui.removeCallbacks(sender); send('S')
        if (::statusBar.isInitialized) statusBar.text = statusText()
    }

    // ---------- Permission ----------
    private var afterPerm: (() -> Unit)? = null
    private fun ensurePermissions(then: () -> Unit) {
        val need = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) then() else { afterPerm = then; requestPermissions(missing.toTypedArray(), 1) }
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) afterPerm?.invoke()
        else toast("ต้องอนุญาต Permission Bluetooth ก่อนใช้งาน")
        afterPerm = null
    }

    // ---------- ความปลอดภัย: แอปไม่อยู่หน้าจอ -> หยุดรถ ----------
    override fun onPause() { super.onPause(); if (connected) release() }
    override fun onDestroy() { stopScan(); if (connected) { try { out?.write('S'.code); out?.flush() } catch (_: Exception) {} }; closeSocket(); super.onDestroy() }

    private fun setScreen(v: View) { root.removeAllViews(); root.addView(v, FrameLayout.LayoutParams(-1, -1)) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
