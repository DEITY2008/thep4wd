// THEP 4WD - ESP32 Firmware (Bluetooth Classic SPP)
// ทดสอบด้วย Arduino IDE + ESP32 board package (Espressif) บนคอมพิวเตอร์
// *** ถอดล้อ/ยกรถลอยขึ้นก่อนทดสอบครั้งแรก ***
#include "BluetoothSerial.h"

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error Bluetooth ไม่ถูกเปิดในบอร์ดนี้
#endif

BluetoothSerial SerialBT;

// ---- ฝั่งซ้าย (L298N ตัวที่ 1) ----
const int L_IN1 = 18, L_IN2 = 19, L_IN3 = 21, L_IN4 = 22;
// ---- ฝั่งขวา (L298N ตัวที่ 2) ----  (ห้ามใช้ GPIO34/35 เพราะเป็น input-only)
const int R_IN1 = 33, R_IN2 = 32, R_IN3 = 26, R_IN4 = 27;

// ถ้าล้อฝั่งไหนหมุนกลับทิศ ให้สลับค่า true/false ตรงนี้ (ไม่ต้องย้ายสาย)
const bool INVERT_LEFT  = false;
const bool INVERT_RIGHT = false;

const unsigned long FAILSAFE_MS = 500;  // ไม่มีคำสั่งเกินนี้ -> หยุด
unsigned long lastCmdMs = 0;
char current = 'S';

// dir: 1 เดินหน้า, -1 ถอยหลัง, 0 หยุด
void setSide(int a, int b, int c, int d, int dir, bool inv) {
  if (inv) dir = -dir;
  bool fwd = (dir > 0), back = (dir < 0);
  // มอเตอร์คู่ (IN1/IN2) และ (IN3/IN4) หน้า-หลังของฝั่งเดียวกัน
  digitalWrite(a, fwd);  digitalWrite(b, back);
  digitalWrite(c, fwd);  digitalWrite(d, back);
}

void drive(int left, int right) {
  setSide(L_IN1, L_IN2, L_IN3, L_IN4, left,  INVERT_LEFT);
  setSide(R_IN1, R_IN2, R_IN3, R_IN4, right, INVERT_RIGHT);
}

void stopAll() { drive(0, 0); current = 'S'; }

void apply(char c) {
  switch (c) {
    case 'F': drive( 1,  1); break;
    case 'B': drive(-1, -1); break;
    case 'L': drive(-1,  1); break;  // หมุนซ้ายอยู่กับที่
    case 'R': drive( 1, -1); break;  // หมุนขวาอยู่กับที่
    case 'S': default: drive(0, 0); c = 'S'; break;
  }
  current = c;
}

void btEvent(esp_spp_cb_event_t event, esp_spp_cb_param_t *param) {
  if (event == ESP_SPP_CLOSE_EVT) stopAll();   // Bluetooth หลุด -> หยุดทันที
}

void setup() {
  int pins[] = {L_IN1,L_IN2,L_IN3,L_IN4,R_IN1,R_IN2,R_IN3,R_IN4};
  for (int p : pins) { pinMode(p, OUTPUT); digitalWrite(p, LOW); }
  Serial.begin(115200);
  SerialBT.register_callback(btEvent);
  SerialBT.begin("THEP_4WD");
  Serial.println("THEP_4WD พร้อมแล้ว");
}

void loop() {
  while (SerialBT.available()) {
    char c = toupper(SerialBT.read());
    if (c=='F'||c=='B'||c=='L'||c=='R'||c=='S') {
      apply(c);
      lastCmdMs = millis();
      SerialBT.print("OK:"); SerialBT.println(c);
      Serial.print("CMD "); Serial.println(c);
    }
  }
  if (current != 'S' && millis() - lastCmdMs > FAILSAFE_MS) {
    stopAll();
    SerialBT.println("FAILSAFE:STOP");
  }
}
